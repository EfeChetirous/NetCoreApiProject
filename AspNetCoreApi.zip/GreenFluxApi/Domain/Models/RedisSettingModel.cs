﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GreenFluxApi.Domain.Models
{
    public class RedisSettingModel
    {
        public int TimeoutValue { get; set; }
    }
}
